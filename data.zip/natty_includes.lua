require('natty_helper_data.lua')
require('natty_helper_functions.lua')

include('default_sets.lua')
include('augments.lua')
