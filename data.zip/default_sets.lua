if not sets then sets = T {} end

if not sets.resist then sets.resist = T {} end
sets.resist.death = {
    ring1 = "Eihwaz Ring", ring2 = "Shadow Ring",
}
